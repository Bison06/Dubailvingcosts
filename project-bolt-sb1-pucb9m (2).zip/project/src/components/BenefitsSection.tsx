import React from 'react';
import { Briefcase } from 'lucide-react';

interface BenefitsSectionProps {
  className?: string;
}

export function BenefitsSection({ className }: BenefitsSectionProps) {
  return (
    <div className={className}>
      <div className="flex items-center gap-2 mb-3">
        <Briefcase className="h-5 w-5 text-gray-600" />
        <label className="form-label">Company Benefits</label>
      </div>
      <div className="grid grid-cols-2 gap-x-4 gap-y-2">
        <div className="checkbox-wrapper">
          <input
            type="checkbox"
            name="benefitHousing"
            id="benefitHousing"
          />
          <label htmlFor="benefitHousing">Housing Contribution</label>
        </div>
        <div className="checkbox-wrapper">
          <input
            type="checkbox"
            name="benefitEducation"
            id="benefitEducation"
          />
          <label htmlFor="benefitEducation">Education Contribution</label>
        </div>
        <div className="checkbox-wrapper">
          <input
            type="checkbox"
            name="benefitHealth"
            id="benefitHealth"
          />
          <label htmlFor="benefitHealth">Health Insurance</label>
        </div>
        <div className="checkbox-wrapper">
          <input
            type="checkbox"
            name="benefitTransport"
            id="benefitTransport"
          />
          <label htmlFor="benefitTransport">Transport</label>
        </div>
        <div className="checkbox-wrapper">
          <input
            type="checkbox"
            name="benefitFlight"
            id="benefitFlight"
          />
          <label htmlFor="benefitFlight">Flight Home</label>
        </div>
      </div>
    </div>
  );
}