import React, { useState } from 'react';
import { PersonalDetailsForm } from './expense-form/PersonalDetailsForm';
import { ExpensesDetailsForm } from './expense-form/ExpensesDetailsForm';
import { type ExpenseFormData } from '../types/expense';
import { X } from 'lucide-react';

interface ExpenseFormProps {
  onSubmit: (expense: any) => void;
  onCancel: () => void;
}

export function ExpenseForm({ onSubmit, onCancel }: ExpenseFormProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<ExpenseFormData>>({
    household: { adults: 1, children: 0 },
    pets: { hasPets: false, dogs: 0, cats: 0 },
    companyBenefits: {
      housing: false,
      education: false,
      health: false,
      transport: false,
      flight: false,
    },
  });

  const handlePersonalDetailsSubmit = (data: Partial<ExpenseFormData>) => {
    setFormData({ ...formData, ...data });
    setStep(2);
  };

  const handleExpensesSubmit = (data: Partial<ExpenseFormData>) => {
    const finalData = {
      ...formData,
      ...data,
      id: crypto.randomUUID(),
      userId: 'anonymous',
      createdAt: new Date(),
    };
    onSubmit(finalData);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg max-w-2xl mx-auto">
      <div className="p-6 space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-xl font-bold text-gray-900">Share Your Experience</h2>
            <p className="mt-1 text-sm text-gray-600">Help others understand the cost of living in Dubai</p>
          </div>
          <button onClick={onCancel} className="text-gray-400 hover:text-gray-500">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="bg-blue-50 p-3 rounded-md">
          <p className="text-sm text-blue-600">
            <span className="font-semibold">Privacy Notice:</span> Your personal information remains private. Only anonymous data about expenses and living conditions will be shared with the community.
          </p>
        </div>

        <div className="relative">
          <div className="absolute top-0 left-0 w-full">
            <div className="h-2 bg-gray-200 rounded">
              <div 
                className="h-full bg-blue-600 rounded transition-all duration-300"
                style={{ width: `${step * 50}%` }}
              />
            </div>
          </div>
          <div className="flex justify-between mb-8 pt-6">
            <div className="text-center">
              <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center mx-auto mb-2 ${
                step >= 1 ? 'border-blue-600 bg-blue-600 text-white' : 'border-gray-300 text-gray-500'
              }`}>
                1
              </div>
              <div className="text-sm text-gray-600">Personal Details</div>
            </div>
            <div className="text-center">
              <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center mx-auto mb-2 ${
                step >= 2 ? 'border-blue-600 bg-blue-600 text-white' : 'border-gray-300 text-gray-500'
              }`}>
                2
              </div>
              <div className="text-sm text-gray-600">Monthly Expenses</div>
            </div>
          </div>
        </div>

        {step === 1 ? (
          <PersonalDetailsForm 
            initialData={formData}
            onSubmit={handlePersonalDetailsSubmit}
            onCancel={onCancel}
          />
        ) : (
          <ExpensesDetailsForm
            initialData={formData}
            onSubmit={handleExpensesSubmit}
            onBack={() => setStep(1)}
            onCancel={onCancel}
          />
        )}
      </div>
    </div>
  );
}