import React from 'react';
import { Building2, Users, Dog, Cat, Home } from 'lucide-react';
import { type Expense } from '../types/expense';
import { formatCurrency } from '../lib/utils';
import { areaImages } from '../data/areaImages';

interface ExpenseCardProps {
  expense: Expense;
}

export function ExpenseCard({ expense }: ExpenseCardProps) {
  const totalMonthly = 
    expense.rent + 
    expense.utilities + 
    expense.internet + 
    expense.groceries + 
    expense.transportation + 
    expense.leisure;
  
  const totalYearly = totalMonthly * 12;

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow overflow-hidden">
      <div className="relative h-48 overflow-hidden">
        <img
          src={areaImages[expense.location.area]}
          alt={expense.location.area}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <h3 className="absolute bottom-4 left-4 text-xl font-semibold text-white">
          {expense.location.area}
        </h3>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-gray-600" />
            <span className="text-gray-700">
              {expense.household.adults} {expense.household.adults === 1 ? 'adult' : 'adults'}
            </span>
          </div>
          {expense.household.children > 0 && (
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-gray-600" />
              <span className="text-gray-700">
                {expense.household.children} {expense.household.children === 1 ? 'child' : 'children'}
              </span>
            </div>
          )}
          {expense.pets.hasPets && (
            <div className="flex items-center gap-2">
              {expense.pets.dogs > 0 && (
                <>
                  <Dog className="w-5 h-5 text-gray-600" />
                  <span className="text-gray-700 mr-2">
                    {expense.pets.dogs} {expense.pets.dogs === 1 ? 'dog' : 'dogs'}
                  </span>
                </>
              )}
              {expense.pets.cats > 0 && (
                <>
                  <Cat className="w-5 h-5 text-gray-600" />
                  <span className="text-gray-700">
                    {expense.pets.cats} {expense.pets.cats === 1 ? 'cat' : 'cats'}
                  </span>
                </>
              )}
            </div>
          )}
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-gray-600" />
            <span className="text-gray-700">{expense.propertyType}</span>
          </div>
          <div className="flex items-center gap-2">
            <Home className="w-5 h-5 text-gray-600" />
            <span className="text-gray-700">{expense.bedrooms} BR</span>
          </div>
        </div>

        <div className="space-y-2 border-t pt-4">
          <div className="flex justify-between">
            <span className="text-gray-600">Rent</span>
            <span className="font-medium">{formatCurrency(expense.rent)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Utilities</span>
            <span className="font-medium">{formatCurrency(expense.utilities)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Internet</span>
            <span className="font-medium">{formatCurrency(expense.internet)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Groceries</span>
            <span className="font-medium">{formatCurrency(expense.groceries)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Transportation</span>
            <span className="font-medium">{formatCurrency(expense.transportation)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Leisure</span>
            <span className="font-medium">{formatCurrency(expense.leisure)}</span>
          </div>
        </div>
        
        <div className="mt-6 pt-4 border-t">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg">
              <p className="text-xs text-blue-700 font-semibold uppercase tracking-wider mb-1">Monthly Total</p>
              <div className="text-xl font-bold text-blue-700">
                <span className="text-sm font-medium">AED</span>{' '}
                {totalMonthly.toLocaleString()}
              </div>
            </div>
            <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 p-4 rounded-lg">
              <p className="text-xs text-emerald-700 font-semibold uppercase tracking-wider mb-1">Yearly Total</p>
              <div className="text-xl font-bold text-emerald-700">
                <span className="text-sm font-medium">AED</span>{' '}
                {totalYearly.toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}