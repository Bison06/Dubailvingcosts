import React from 'react';
import { type Expense } from '../types/expense';

interface ExpenseFiltersProps {
  filters: {
    area: string;
    bedrooms: string;
    pets: boolean;
  };
  onFilterChange: (name: string, value: string | boolean) => void;
  expenses: Expense[];
}

export function ExpenseFilters({ filters, onFilterChange, expenses }: ExpenseFiltersProps) {
  // Get unique areas from existing expense data
  const availableAreas = React.useMemo(() => {
    const areas = new Set(expenses.map(expense => expense.location.area));
    return Array.from(areas).sort();
  }, [expenses]);

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="form-group">
          <label className="form-label" htmlFor="area">Area</label>
          <select
            id="area"
            value={filters.area}
            onChange={(e) => onFilterChange('area', e.target.value)}
            className="w-full"
          >
            <option value="">All areas</option>
            {availableAreas.map((area) => (
              <option key={area} value={area}>
                {area}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="bedrooms">Bedrooms</label>
          <select
            id="bedrooms"
            value={filters.bedrooms}
            onChange={(e) => onFilterChange('bedrooms', e.target.value)}
            className="w-full"
          >
            <option value="">Any</option>
            <option value="0">Studio</option>
            <option value="1">1 Bedroom</option>
            <option value="2">2 Bedrooms</option>
            <option value="3">3 Bedrooms</option>
            <option value="4">4 Bedrooms</option>
            <option value="5">5+ Bedrooms</option>
          </select>
        </div>

        <div className="form-group">
          <label className="form-label mb-2">&nbsp;</label>
          <div className="checkbox-wrapper">
            <input
              type="checkbox"
              id="pets"
              checked={filters.pets}
              onChange={(e) => onFilterChange('pets', e.target.checked)}
            />
            <label htmlFor="pets">Pet-Friendly Only</label>
          </div>
        </div>
      </div>
    </div>
  );
}