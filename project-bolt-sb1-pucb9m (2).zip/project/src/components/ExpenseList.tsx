import React, { useState } from 'react';
import { ExpenseCard } from './ExpenseCard';
import { ExpenseFilters } from './ExpenseFilters';
import { type Expense } from '../types/expense';

interface ExpenseListProps {
  expenses: Expense[];
}

export function ExpenseList({ expenses }: ExpenseListProps) {
  const [filters, setFilters] = useState({
    area: '',
    bedrooms: '',
    pets: false,
  });

  const handleFilterChange = (name: string, value: string | boolean) => {
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const filteredExpenses = expenses.filter((expense) => {
    const matchesArea = !filters.area || expense.location.area === filters.area;
    const matchesBedrooms = !filters.bedrooms || expense.bedrooms === Number(filters.bedrooms);
    const matchesPets = !filters.pets || expense.pets.hasPets;

    return matchesArea && matchesBedrooms && matchesPets;
  });

  return (
    <div className="space-y-6">
      <ExpenseFilters
        filters={filters}
        onFilterChange={handleFilterChange}
        expenses={expenses}
      />

      {filteredExpenses.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500">No expenses found. Be the first to share your living expenses!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredExpenses.map((expense) => (
            <ExpenseCard key={expense.id} expense={expense} />
          ))}
        </div>
      )}
    </div>
  );
}