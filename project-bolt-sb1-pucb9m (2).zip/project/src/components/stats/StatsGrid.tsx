import React, { useMemo } from 'react';
import { TrendingUp, TrendingDown, Users, DollarSign, Dog, Home } from 'lucide-react';
import { StatCard } from './StatCard';
import { type Expense } from '../../types/expense';
import { formatCurrency } from '../../lib/utils';

interface StatsGridProps {
  expenses: Expense[];
}

export function StatsGrid({ expenses }: StatsGridProps) {
  const stats = useMemo(() => {
    if (expenses.length === 0) {
      return {
        mostExpensiveArea: { area: 'N/A', amount: 'N/A' },
        mostAffordableArea: { area: 'N/A', amount: 'N/A' },
        totalSubmissions: 0,
        petFriendlyAreas: 0,
        familyFriendlyAreas: 0,
        averageRent: 'N/A'
      };
    }

    const areaStats = expenses.reduce((acc, expense) => {
      const area = expense.location.area;
      const totalCost = expense.rent + expense.utilities + expense.internet + 
                       expense.groceries + expense.transportation + expense.leisure;

      if (!acc[area]) {
        acc[area] = {
          totalCost: 0,
          count: 0,
          hasPets: 0,
          hasFamily: 0,
        };
      }

      acc[area].totalCost += totalCost;
      acc[area].count += 1;
      if (expense.pets.hasPets) acc[area].hasPets += 1;
      if (expense.familySize > 1) acc[area].hasFamily += 1;

      return acc;
    }, {} as Record<string, { totalCost: number; count: number; hasPets: number; hasFamily: number; }>);

    const areaAverages = Object.entries(areaStats).map(([area, stats]) => ({
      area,
      averageCost: stats.totalCost / stats.count,
      petFriendly: stats.hasPets / stats.count > 0.5,
      familyFriendly: stats.hasFamily / stats.count > 0.5,
    }));

    const sortedByPrice = [...areaAverages].sort((a, b) => b.averageCost - a.averageCost);
    const totalRent = expenses.reduce((sum, exp) => sum + exp.rent, 0);

    return {
      mostExpensiveArea: {
        area: sortedByPrice[0].area,
        amount: formatCurrency(sortedByPrice[0].averageCost)
      },
      mostAffordableArea: {
        area: sortedByPrice[sortedByPrice.length - 1].area,
        amount: formatCurrency(sortedByPrice[sortedByPrice.length - 1].averageCost)
      },
      totalSubmissions: expenses.length,
      petFriendlyAreas: areaAverages.filter(a => a.petFriendly).length,
      familyFriendlyAreas: areaAverages.filter(a => a.familyFriendly).length,
      averageRent: formatCurrency(totalRent / expenses.length)
    };
  }, [expenses]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
      <StatCard
        title="Most Expensive Area"
        value={stats.mostExpensiveArea.area}
        subtitle={`Average monthly cost: ${stats.mostExpensiveArea.amount}`}
        icon={<TrendingUp className="h-6 w-6 text-red-600" />}
        iconClassName="bg-red-100"
      />
      
      <StatCard
        title="Most Affordable Area"
        value={stats.mostAffordableArea.area}
        subtitle={`Average monthly cost: ${stats.mostAffordableArea.amount}`}
        icon={<TrendingDown className="h-6 w-6 text-green-600" />}
        iconClassName="bg-green-100"
      />

      <StatCard
        title="Community Data"
        value={stats.totalSubmissions}
        subtitle="Expense reports shared"
        icon={<DollarSign className="h-6 w-6 text-blue-600" />}
        iconClassName="bg-blue-100"
      />

      <StatCard
        title="Pet-Friendly Areas"
        value={stats.petFriendlyAreas}
        subtitle="Areas with high pet ownership"
        icon={<Dog className="h-6 w-6 text-purple-600" />}
        iconClassName="bg-purple-100"
      />

      <StatCard
        title="Family-Friendly Areas"
        value={stats.familyFriendlyAreas}
        subtitle="Areas popular with families"
        icon={<Users className="h-6 w-6 text-orange-600" />}
        iconClassName="bg-orange-100"
      />

      <StatCard
        title="Average Rent"
        value={stats.averageRent}
        subtitle="Monthly rent across all areas"
        icon={<Home className="h-6 w-6 text-indigo-600" />}
        iconClassName="bg-indigo-100"
      />
    </div>
  );
}