import React from 'react';
import { cn } from '../../lib/utils';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle: string;
  icon: React.ReactNode;
  iconClassName?: string;
}

export function StatCard({ title, value, subtitle, icon, iconClassName }: StatCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-sm font-medium text-gray-500">{title}</h3>
          <div className="mt-2 flex items-baseline">
            <p className="text-3xl font-semibold text-gray-900">{value}</p>
          </div>
          <p className="mt-1 text-sm text-gray-600">{subtitle}</p>
        </div>
        <div className={cn("p-3 rounded-full", iconClassName)}>
          {icon}
        </div>
      </div>
    </div>
  );
}