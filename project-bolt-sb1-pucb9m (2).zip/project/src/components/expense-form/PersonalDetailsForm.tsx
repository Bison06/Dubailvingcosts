import React, { useState } from 'react';
import { Users, Dog, Cat, Briefcase } from 'lucide-react';
import { type ExpenseFormData } from '../../types/expense';
import { BenefitsSection } from '../BenefitsSection';
import { DUBAI_AREAS } from '../../constants/areas';

interface PersonalDetailsFormProps {
  initialData: Partial<ExpenseFormData>;
  onSubmit: (data: Partial<ExpenseFormData>) => void;
  onCancel: () => void;
}

export function PersonalDetailsForm({ initialData, onSubmit, onCancel }: PersonalDetailsFormProps) {
  const [hasPets, setHasPets] = useState(initialData.pets?.hasPets || false);
  const [dogs, setDogs] = useState(initialData.pets?.dogs || 0);
  const [cats, setCats] = useState(initialData.pets?.cats || 0);
  const [adults, setAdults] = useState(initialData.household?.adults || 1);
  const [children, setChildren] = useState(initialData.household?.children || 0);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    onSubmit({
      location: {
        area: formData.get('area') as string,
      },
      household: {
        adults,
        children,
      },
      pets: {
        hasPets,
        dogs,
        cats,
      },
      propertyType: formData.get('propertyType') as string,
      bedrooms: Number(formData.get('bedrooms')),
      housingStatus: formData.get('housingStatus') as string,
      workStyle: formData.get('workStyle') as string,
      companyBenefits: {
        housing: formData.get('benefitHousing') === 'on',
        education: formData.get('benefitEducation') === 'on',
        health: formData.get('benefitHealth') === 'on',
        transport: formData.get('benefitTransport') === 'on',
        flight: formData.get('benefitFlight') === 'on',
      },
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="form-group">
        <div className="flex items-center gap-2 mb-3">
          <Users className="h-5 w-5 text-gray-600" />
          <label className="form-label">Household Size</label>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="form-label text-sm" htmlFor="adults">Adults</label>
            <input
              type="number"
              id="adults"
              min="1"
              value={adults}
              onChange={(e) => setAdults(Number(e.target.value))}
              className="w-full"
              required
            />
          </div>
          <div>
            <label className="form-label text-sm" htmlFor="children">Children</label>
            <input
              type="number"
              id="children"
              min="0"
              value={children}
              onChange={(e) => setChildren(Number(e.target.value))}
              className="w-full"
            />
          </div>
        </div>
      </div>

      <div className="form-group">
        <label className="form-label">Pets</label>
        <div className="space-y-2">
          <div className="checkbox-wrapper">
            <input
              type="checkbox"
              id="hasPets"
              checked={hasPets}
              onChange={(e) => setHasPets(e.target.checked)}
            />
            <label htmlFor="hasPets">Have Pets</label>
          </div>
          {hasPets && (
            <div className="grid grid-cols-2 gap-2 mt-2">
              <div className="form-group">
                <div className="flex items-center gap-2 mb-1">
                  <Dog className="h-4 w-4 text-gray-500" />
                  <label htmlFor="numDogs" className="text-sm text-gray-700">Dogs</label>
                </div>
                <input
                  type="number"
                  id="numDogs"
                  min="0"
                  value={dogs}
                  onChange={(e) => setDogs(Number(e.target.value))}
                  className="w-full"
                />
              </div>
              <div className="form-group">
                <div className="flex items-center gap-2 mb-1">
                  <Cat className="h-4 w-4 text-gray-500" />
                  <label htmlFor="numCats" className="text-sm text-gray-700">Cats</label>
                </div>
                <input
                  type="number"
                  id="numCats"
                  min="0"
                  value={cats}
                  onChange={(e) => setCats(Number(e.target.value))}
                  className="w-full"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="form-group">
        <label className="form-label" htmlFor="propertyType">Property Type</label>
        <select
          id="propertyType"
          name="propertyType"
          required
          className="w-full"
        >
          <option value="Apartment">Apartment</option>
          <option value="Villa">Villa</option>
          <option value="Townhouse">Townhouse</option>
        </select>
      </div>

      <div className="form-group">
        <label className="form-label" htmlFor="area">Location</label>
        <select
          id="area"
          name="area"
          required
          className="w-full"
        >
          <option value="">Select an area...</option>
          {DUBAI_AREAS.map((area) => (
            <option key={area} value={area}>
              {area}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="form-group">
          <label className="form-label" htmlFor="bedrooms">Bedrooms</label>
          <input
            type="number"
            id="bedrooms"
            name="bedrooms"
            min="0"
            defaultValue="1"
            required
            className="w-full"
          />
        </div>
        <div className="form-group">
          <label className="form-label" htmlFor="housingStatus">Housing Status</label>
          <select
            id="housingStatus"
            name="housingStatus"
            required
            className="w-full"
          >
            <option value="Renting">Renting</option>
            <option value="Owned">Owned</option>
          </select>
        </div>
      </div>

      <div className="form-group">
        <label className="form-label" htmlFor="workStyle">Work Style</label>
        <select
          id="workStyle"
          name="workStyle"
          required
          className="w-full"
        >
          <option value="Office Based">Office Based</option>
          <option value="Hybrid">Hybrid</option>
          <option value="Remote">Remote</option>
        </select>
      </div>

      <BenefitsSection className="form-group" />

      <div className="flex justify-end space-x-3">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm border border-transparent rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
        >
          Next
        </button>
      </div>
    </form>
  );
}