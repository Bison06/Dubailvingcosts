import React from 'react';
import { Wallet } from 'lucide-react';
import { type ExpenseFormData } from '../../types/expense';

interface ExpensesDetailsFormProps {
  initialData: Partial<ExpenseFormData>;
  onSubmit: (data: Partial<ExpenseFormData>) => void;
  onBack: () => void;
  onCancel: () => void;
}

export function ExpensesDetailsForm({ onSubmit, onBack, onCancel }: ExpensesDetailsFormProps) {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    onSubmit({
      rent: Number(formData.get('rent')),
      utilities: Number(formData.get('utilities')),
      internet: Number(formData.get('internet')),
      groceries: Number(formData.get('groceries')),
      transportation: Number(formData.get('transportation')),
      leisure: Number(formData.get('leisure')),
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Wallet className="h-5 w-5 text-gray-600" />
        <h3 className="text-lg font-medium text-gray-900">Monthly Expenses</h3>
      </div>

      <div className="space-y-4">
        <div className="form-group">
          <label className="form-label" htmlFor="rent">Rent (AED)</label>
          <input
            type="number"
            id="rent"
            name="rent"
            min="0"
            required
            className="w-full"
            placeholder="e.g., 5000"
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="utilities">Utilities (DEWA, AC) (AED)</label>
          <input
            type="number"
            id="utilities"
            name="utilities"
            min="0"
            required
            className="w-full"
            placeholder="e.g., 500"
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="internet">Internet & TV (AED)</label>
          <input
            type="number"
            id="internet"
            name="internet"
            min="0"
            required
            className="w-full"
            placeholder="e.g., 350"
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="groceries">Groceries (AED)</label>
          <input
            type="number"
            id="groceries"
            name="groceries"
            min="0"
            required
            className="w-full"
            placeholder="e.g., 2000"
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="transportation">Transportation (AED)</label>
          <input
            type="number"
            id="transportation"
            name="transportation"
            min="0"
            required
            className="w-full"
            placeholder="e.g., 500"
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="leisure">Leisure & Entertainment (AED)</label>
          <input
            type="number"
            id="leisure"
            name="leisure"
            min="0"
            required
            className="w-full"
            placeholder="e.g., 1000"
          />
        </div>
      </div>

      <div className="flex justify-end space-x-3">
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-2 text-sm border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
        >
          Back
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm border border-transparent rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
        >
          Share Experience
        </button>
      </div>
    </form>
  );
}