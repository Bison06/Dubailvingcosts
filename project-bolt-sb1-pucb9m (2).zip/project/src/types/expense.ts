export interface Location {
  area: string;
}

export interface Pets {
  hasPets: boolean;
  dogs: number;
  cats: number;
}

export interface CompanyBenefits {
  housing: boolean;
  education: boolean;
  health: boolean;
  transport: boolean;
  flight: boolean;
}

export interface HouseholdSize {
  adults: number;
  children: number;
}

export interface Expense {
  id: string;
  userId: string;
  location: Location;
  household: HouseholdSize;
  pets: Pets;
  propertyType: string;
  bedrooms: number;
  housingStatus: string;
  workStyle: string;
  companyBenefits: CompanyBenefits;
  rent: number;
  utilities: number;
  internet: number;
  groceries: number;
  transportation: number;
  leisure: number;
  createdAt: Date;
}

export interface ExpenseFormData extends Omit<Expense, 'id' | 'userId' | 'createdAt'> {}