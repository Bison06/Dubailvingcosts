interface AreaImage {
  [key: string]: string;
}

export const areaImages: AreaImage = {
  'Dubai Marina': 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=800&h=400',
  'Downtown Dubai': 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=800&h=400',
  'Arabian Ranches 2': 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=800&h=400'
};