import { type Expense } from '../types/expense';

export const dummyExpenses: Expense[] = [
  {
    id: '1',
    userId: 'anonymous',
    location: {
      area: 'Dubai Marina'
    },
    household: {
      adults: 2,
      children: 1
    },
    pets: {
      hasPets: true,
      dogs: 1,
      cats: 0
    },
    propertyType: 'Apartment',
    bedrooms: 2,
    housingStatus: 'Renting',
    workStyle: 'Hybrid',
    companyBenefits: {
      housing: true,
      education: true,
      health: true,
      transport: false,
      flight: true
    },
    rent: 8500,
    utilities: 800,
    internet: 389,
    groceries: 2500,
    transportation: 600,
    leisure: 2000,
    createdAt: new Date('2024-03-15')
  },
  {
    id: '2',
    userId: 'anonymous',
    location: {
      area: 'Downtown Dubai'
    },
    household: {
      adults: 1,
      children: 0
    },
    pets: {
      hasPets: false,
      dogs: 0,
      cats: 0
    },
    propertyType: 'Apartment',
    bedrooms: 1,
    housingStatus: 'Renting',
    workStyle: 'Office Based',
    companyBenefits: {
      housing: false,
      education: false,
      health: true,
      transport: true,
      flight: true
    },
    rent: 7000,
    utilities: 600,
    internet: 350,
    groceries: 1500,
    transportation: 300,
    leisure: 1500,
    createdAt: new Date('2024-03-14')
  },
  {
    id: '3',
    userId: 'anonymous',
    location: {
      area: 'Arabian Ranches 2'
    },
    household: {
      adults: 2,
      children: 2
    },
    pets: {
      hasPets: true,
      dogs: 1,
      cats: 1
    },
    propertyType: 'Villa',
    bedrooms: 4,
    housingStatus: 'Owned',
    workStyle: 'Remote',
    companyBenefits: {
      housing: true,
      education: true,
      health: true,
      transport: false,
      flight: true
    },
    rent: 15000,
    utilities: 2000,
    internet: 500,
    groceries: 4000,
    transportation: 1200,
    leisure: 3000,
    createdAt: new Date('2024-03-13')
  }
];