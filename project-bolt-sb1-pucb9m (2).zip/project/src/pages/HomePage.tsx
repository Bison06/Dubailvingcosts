import React from 'react';
import { ExpenseList } from '../components/ExpenseList';
import { type Expense } from '../types/expense';

interface HomePageProps {
  expenses: Expense[];
}

export function HomePage({ expenses }: HomePageProps) {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="max-w-3xl mx-auto text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Cost of Living in Dubai
        </h1>
        <p className="text-xl text-gray-600 mb-6">
          Make informed decisions about where to live in Dubai based on real community experiences
        </p>
        <div className="prose prose-blue mx-auto text-gray-500">
          <p>
            Understanding the cost of living in Dubai is crucial for making smart financial decisions. 
            Our community-driven platform provides real insights into housing and living expenses 
            across different areas of Dubai.
          </p>
        </div>
      </div>

      <ExpenseList expenses={expenses} />
    </main>
  );
}