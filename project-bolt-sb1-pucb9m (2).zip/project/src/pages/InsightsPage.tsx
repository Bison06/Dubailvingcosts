import React from 'react';
import { StatsGrid } from '../components/stats/StatsGrid';
import { type Expense } from '../types/expense';

interface InsightsPageProps {
  expenses: Expense[];
}

export function InsightsPage({ expenses }: InsightsPageProps) {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="max-w-3xl mx-auto text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Community Insights
        </h1>
        <p className="text-xl text-gray-600 mb-6">
          Discover trends and patterns in Dubai's living expenses
        </p>
        <div className="prose prose-blue mx-auto text-gray-500">
          <p>
            Get valuable insights into Dubai's housing market and living costs. 
            Our community data helps you understand which areas best match your lifestyle and budget.
          </p>
        </div>
      </div>

      <StatsGrid expenses={expenses} />
    </main>
  );
}