import React, { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Navigation } from './components/Navigation';
import { HomePage } from './pages/HomePage';
import { InsightsPage } from './pages/InsightsPage';
import { ExpenseForm } from './components/ExpenseForm';
import { type Expense } from './types/expense';
import { dummyExpenses } from './data/dummyExpenses';

function App() {
  const [showForm, setShowForm] = useState(false);
  const [expenses, setExpenses] = useState<Expense[]>(dummyExpenses);

  const handleAddExpense = (expense: Expense) => {
    setExpenses([...expenses, expense]);
    setShowForm(false);
  };

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-50">
        <Navigation onShareClick={() => setShowForm(true)} />
        
        {showForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto">
            <div className="min-h-screen px-4 text-center">
              <div className="inline-block w-full max-w-2xl my-8 text-left align-middle">
                <ExpenseForm 
                  onSubmit={handleAddExpense} 
                  onCancel={() => setShowForm(false)} 
                />
              </div>
            </div>
          </div>
        )}

        <Routes>
          <Route path="/" element={<HomePage expenses={expenses} />} />
          <Route path="/insights" element={<InsightsPage expenses={expenses} />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;